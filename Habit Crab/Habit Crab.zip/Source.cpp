#include <iostream>
#include <vector>
#include <ctime>
#include <cmath>
#include <string>
#include "Inputs.h"
#include "HabitName.h"
#include "HabitTime.h"
#include "HabitFrequency.h"
#include "HabitImportance.h"
#include "Reward.h"
#include "RewardLevel.h"

using namespace std;

vector <string>HabitInput;
vector <int>PointTracker;
string userName;

int main()
{
	initialize();



}