#pragma once
#include <iostream>
#include <vector>
#include <ctime>
#include <cmath>
#include <string>

#include "Inputs.h"
#include "HabitName.h"
#include "HabitTime.h"
#include "HabitFrequency.h"
#include "HabitImportance.h"
#include "Reward.h"

using namespace std;