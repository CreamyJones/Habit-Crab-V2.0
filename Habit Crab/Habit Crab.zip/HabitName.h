#pragma once
#include <iostream>
#include <vector>
#include <ctime>
#include <cmath>
#include <string>

#include "Inputs.h"
#include "HabitTime.h"
#include "HabitFrequency.h"
#include "HabitImportance.h"
#include "Reward.h"
#include "RewardLevel.h"
using namespace std;

void HabitName()
{
	vector <string>Hourly;
	vector <string>Daily;
	vector <string>Weekly;
	vector <string>Monthly;
	vector <string>Yearly;
	int i;

	string frequency;

	string userInp;

	cout << "Choose which list you'd like to populate: \n";
	cout << " 1) Hourly\n 2) Daily\n 3) Weekly\n 4) Monthly\n 5) Yearly\n";
	cin >> i;

	switch (i)
	{
	case 1:

		cout << "Go ahead and enter which habits you'd like to track every hour. Press enter after each input, and type 'done' when finished.\n";

		while (true) //use getline here in some capacity
		{
			cin >> userInp;

			if (userInp == "done" || userInp == "Done")
			{
				cout << "Sure! let's move on.\n";
				break;
			}

			Hourly.push_back(userInp);

		}

		for (int k = 0; k < Hourly.size(); k++)
		{
			cout << Hourly[k] << ", ";
		}

		break;

	case 2:



		break;

	case 3:



		break;

	case 4:



		break;

	case 5:



		break;

	}




}